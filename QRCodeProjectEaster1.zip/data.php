<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "velikonoce"
?>