
######

This is a start of a project known as egg hunting on Purkyňova Brno

######

######
DONE

######

